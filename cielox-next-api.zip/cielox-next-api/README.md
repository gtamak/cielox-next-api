# CieloX /api/quote (Next.js App Router)

Deploy-ready API for quotes with mock/live modes.

## Env
- API_MODE=mock|live
- CORS_ORIGINS=https://donc.co.za,https://www.donc.co.za
- PROVIDER=none
