// app/api/quote/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { QuoteReq, QuoteRes } from '@/lib/validate'
import { getEnv, isCorsAllowed } from '@/lib/config'

const corridors = { gh:{ccy:'GHS', rate:0.63, spread:0.007}, ke:{ccy:'KES', rate:7.50, spread:0.007}, ng:{ccy:'NGN', rate:42.0, spread:0.009}, gb:{ccy:'GBP', rate:0.043, spread:0.006} } as const
const feeBase = { wallet:10, bank:12, card:18, crypto:8 } as const
const fxAdj = { wallet:0.000, bank:0.001, card:0.001, crypto:-0.002 } as const

function prng(seed: number){ let x = seed | 0; return function(){ x^=x<<13; x^=x>>>17; x^=x<<5; return ((x>>>0)%1000)/1000 } }
function seedFrom(s: string){ let x=0; for(let i=0;i<s.length;i++){ x=(x*31 + s.charCodeAt(i))|0 } return x }

async function quoteFromMock(body: any){
  const { source, country, method, amountZAR } = body
  const base = (corridors as any)[country]
  if(!base) throw new Error('Unsupported corridor')
  const seed = seedFrom(`${source}|${country}|${method}|${Math.round(amountZAR)}`)
  const rnd = prng(seed)
  const dayDrift = (new Date().getUTCDate()%5) * 0.0002
  const spread = Math.max(0, base.spread + (fxAdj as any)[source] + (rnd()-0.5)*0.0006 + dayDrift)
  const rate = base.rate * (1 + (rnd()-0.5)*0.005)
  const fee = (feeBase as any)[source] + Math.round(amountZAR/5000)*1
  const receive = amountZAR * rate * (1 - spread)
  const eta = method==='mm' ? (source==='bank' ? '~30–60 min' : 'Instant') : (source==='bank' ? '~1–3h' : '~30–60 min')
  return { ccy: base.ccy, receive: +receive.toFixed(2), feeZAR: +fee.toFixed(2), spread: +(spread*100).toFixed(2), eta }
}
async function quoteFromLive(body: any){ return quoteFromMock(body) }

export async function OPTIONS(req: NextRequest){
  const env = getEnv(); const origin = req.headers.get('origin')
  const headers: Record<string,string> = { 'Access-Control-Allow-Methods':'POST, OPTIONS', 'Access-Control-Allow-Headers':'Content-Type' }
  if(isCorsAllowed(origin, env.CORS_ORIGINS)){ headers['Access-Control-Allow-Origin'] = origin || '*' }
  return new NextResponse(null, { status: 204, headers })
}
export async function POST(req: NextRequest){
  const env = getEnv(); const origin = req.headers.get('origin')
  let body: unknown; try{ body = await req.json() }catch{ return NextResponse.json({ error:'Invalid JSON' }, { status:400 }) }
  const parsed = QuoteReq.safeParse(body)
  if(!parsed.success){ return NextResponse.json({ error:'Bad request', issues: parsed.error.format() }, { status:400 }) }
  try{
    const data = env.API_MODE === 'live' ? await quoteFromLive(parsed.data) : await quoteFromMock(parsed.data)
    const validated = QuoteRes.parse(data)
    const headers: Record<string,string> = {}
    if(isCorsAllowed(origin, env.CORS_ORIGINS)){ headers['Access-Control-Allow-Origin'] = origin || '*' }
    return NextResponse.json(validated, { headers })
  }catch(e: any){ return NextResponse.json({ error: e?.message || 'Internal error' }, { status:500 }) }
}
