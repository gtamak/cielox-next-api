# CieloX Next.js API (Vercel-ready)

This is a minimal **Next.js App Router** project that exposes:
- `POST /api/quote` (mock/live)

## Deploy
1) Push this folder to a GitHub repo (root level).
2) Import the repo in Vercel → Framework: Next.js
3) Add env vars:
   - `API_MODE=mock`
   - `CORS_ORIGINS=https://donc.co.za,https://www.donc.co.za`
   - `PROVIDER=none`
4) Deploy → test:
```
curl -X POST $YOUR_URL/api/quote -H 'Content-Type: application/json'   -d '{"source":"wallet","country":"gh","method":"mm","amountZAR":1200}'
```

Switch to live later by setting `API_MODE=live` and wiring `quoteFromLive()`.
