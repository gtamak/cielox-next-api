// lib/validate.ts
import { z } from 'zod'
export const QuoteReq = z.object({
  source: z.enum(['wallet','bank','card','crypto']),
  country: z.enum(['gh','ke','ng','gb']),
  method: z.enum(['bank','mm']),
  amountZAR: z.number().positive(),
})
export type QuoteReqT = z.infer<typeof QuoteReq>
export const QuoteRes = z.object({ ccy: z.string(), receive: z.number(), feeZAR: z.number(), spread: z.number(), eta: z.string() })
export type QuoteResT = z.infer<typeof QuoteRes>
