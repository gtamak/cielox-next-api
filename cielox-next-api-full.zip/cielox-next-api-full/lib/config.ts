// lib/config.ts
export type Env = { API_MODE: 'mock'|'live'; CORS_ORIGINS?: string; PROVIDER?: string }
export function getEnv(): Env {
  return {
    API_MODE: (process.env.API_MODE || 'mock') as 'mock' | 'live',
    CORS_ORIGINS: process.env.CORS_ORIGINS || '',
    PROVIDER: process.env.PROVIDER || 'none',
  }
}
export function isCorsAllowed(origin: string | null, allowlistCSV?: string){
  if(!origin) return true
  if(!allowlistCSV) return true
  const allow = allowlistCSV.split(',').map(s => s.trim()).filter(Boolean)
  return allow.some(a => origin === a)
}
